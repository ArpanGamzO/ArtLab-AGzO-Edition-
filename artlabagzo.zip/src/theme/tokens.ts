export const colors = {
  ink: '#12131A',
  panel: '#1B1D28',
  panelRaised: '#262A3D',
  line: '#33374D',
  text: '#EEEAF6',
  textDim: '#A09DBB',
  accent: '#8B7CFF',
  accentText: '#14112B',
  frame: '#FFB547',
  danger: '#FF6B7A',
} as const;

export const fonts = {
  medium: 'BricolageGrotesque_500Medium',
  bold: 'BricolageGrotesque_700Bold',
} as const;

export const radius = { sm: 10, md: 16, pill: 999 } as const;
/** Minimum thumb-friendly touch target (dp). */
export const HIT = 48;
