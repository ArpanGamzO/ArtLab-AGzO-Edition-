export const DOCUMENT_VERSION = 1;

export const BLEND_MODES = [
  'normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten',
  'color-dodge', 'color-burn', 'hard-light', 'soft-light',
  'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity',
] as const;
export type BlendMode = (typeof BLEND_MODES)[number];

export interface Transform2D {
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
  rotation: number; // radians
}

interface LayerBase {
  id: string;
  name: string;
  visible: boolean;
  locked: boolean;
  opacity: number; // 0..1
  blendMode: BlendMode;
  transform: Transform2D;
  maskRef?: string; // file reference, never a temp URI
  clipToBelow?: boolean;
}

export type Layer =
  | (LayerBase & { kind: 'raster'; fileRef: string; width: number; height: number })
  | (LayerBase & { kind: 'text'; text: string; fontFamily: string; fontSize: number; color: string })
  | (LayerBase & { kind: 'shape'; shape: 'rect' | 'ellipse' | 'line' | 'path'; fill: string })
  | (LayerBase & { kind: 'asset'; assetId: string })
  | (LayerBase & { kind: 'adjustment'; adjustment: string; params: Record<string, number> })
  | (LayerBase & { kind: 'group'; children: string[] });

/** Documented in docs/ARCHITECTURE.md. Stored as JSON in <id>.artlab */
export interface ArtLabDocument {
  version: number;
  id: string;
  name: string;
  width: number;
  height: number;
  transparent: boolean;
  background: string;
  layers: Layer[]; // bottom -> top
  createdAt: number;
  updatedAt: number;
}

export const MIN_SIZE = 16;
export const MAX_SIZE = 8192;

export function clampSize(n: number): number {
  if (!Number.isFinite(n)) return MIN_SIZE;
  return Math.min(MAX_SIZE, Math.max(MIN_SIZE, Math.round(n)));
}

export function createEmptyDocument(
  id: string,
  name: string,
  width: number,
  height: number,
): ArtLabDocument {
  const now = Date.now();
  return {
    version: DOCUMENT_VERSION,
    id,
    name,
    width: clampSize(width),
    height: clampSize(height),
    transparent: true,
    background: '#FFFFFF',
    layers: [],
    createdAt: now,
    updatedAt: now,
  };
}
