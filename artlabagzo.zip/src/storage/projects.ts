import { Directory, File, Paths } from 'expo-file-system';
import { ArtLabDocument, DOCUMENT_VERSION, createEmptyDocument } from '../engine/types';
import { getProject, insertProject } from './db';

function projectsDir(): Directory {
  const dir = new Directory(Paths.document, 'projects');
  dir.create({ intermediates: true, idempotent: true });
  return dir;
}

function fileFor(id: string, suffix = ''): File {
  return new File(projectsDir(), `${id}.artlab${suffix}`);
}

function newId(): string {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

/** Write to a temp file, then swap it in, so a crash never leaves a half-written project. */
export function writeDocument(doc: ArtLabDocument): void {
  const tmp = fileFor(doc.id, '.tmp');
  const final = fileFor(doc.id);
  if (tmp.exists) tmp.delete();
  tmp.create();
  tmp.write(JSON.stringify(doc));
  if (final.exists) final.delete();
  tmp.move(final);
}

export async function createProject(name: string, width: number, height: number): Promise<string> {
  const doc = createEmptyDocument(newId(), name.trim() || 'Untitled', width, height);
  writeDocument(doc);
  await insertProject({
    id: doc.id, name: doc.name, width: doc.width, height: doc.height,
    createdAt: doc.createdAt, updatedAt: doc.updatedAt,
  });
  return doc.id;
}

export async function loadDocument(id: string): Promise<ArtLabDocument> {
  const row = await getProject(id);
  if (!row) throw new Error('Project not found.');
  const file = fileFor(id);
  if (!file.exists) throw new Error('Project file is missing from this device.');
  const doc = JSON.parse(await file.text()) as ArtLabDocument;
  if (doc.version > DOCUMENT_VERSION) {
    throw new Error('This project was saved by a newer version of ART LAB.');
  }
  return doc;
}
