import * as SQLite from 'expo-sqlite';

export interface ProjectRow {
  id: string;
  name: string;
  width: number;
  height: number;
  createdAt: number;
  updatedAt: number;
}

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('artlab.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        CREATE TABLE IF NOT EXISTS projects (
          id TEXT PRIMARY KEY NOT NULL,
          name TEXT NOT NULL,
          width INTEGER NOT NULL,
          height INTEGER NOT NULL,
          createdAt INTEGER NOT NULL,
          updatedAt INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
      `);
      return db;
    })();
  }
  return dbPromise;
}

export async function listProjects(): Promise<ProjectRow[]> {
  const db = await getDb();
  return db.getAllAsync<ProjectRow>('SELECT * FROM projects ORDER BY updatedAt DESC');
}

export async function getProject(id: string): Promise<ProjectRow | null> {
  const db = await getDb();
  return db.getFirstAsync<ProjectRow>('SELECT * FROM projects WHERE id = ?', id);
}

export async function insertProject(p: ProjectRow): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO projects (id, name, width, height, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)',
    p.id, p.name, p.width, p.height, p.createdAt, p.updatedAt,
  );
}

export async function getSetting(key: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM settings WHERE key = ?', key);
  return row?.value ?? null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    key, value,
  );
}
