# ART LAB [AGzO Edition]

Native Android + iOS graphics and thumbnail editor (React Native, Expo, strict TypeScript, Skia).

## Get the APK (installs on Android 7.0+, all phone types)
The universal APK (arm64, armv7, x86, x86_64) builds in the cloud, no Android SDK needed.

**GitHub (free, no Expo account):** push this folder to a *public* GitHub repo on branch `main`. The workflow in `.github/workflows/build-apk.yml` builds it (about 15 to 25 minutes). Download `art-lab-agzo.apk` from the repo's Releases page (tag `latest-apk`), or from the run's Artifacts. Open the file on your phone and allow "install unknown apps" for your browser or file manager.

**EAS (Expo account):** `npx eas-cli login` then `eas build --profile preview --platform android`.

The APK is signed with the standard debug key, so it installs and updates over itself. It is not Play Store ready; use `--profile production` with your own keystore for that.

## Develop
```bash
npm install
npx expo install expo-dev-client      # Skia needs a dev build, not just Expo Go
npx eas-cli login
eas build --profile development --platform android   # installs as an APK on your phone
npx expo start --dev-client
```
iOS builds need an Apple developer account: `eas build --platform ios`.

## Checks
`npm run typecheck` (strict TS). `npx expo export --platform android` verifies the bundle compiles.
