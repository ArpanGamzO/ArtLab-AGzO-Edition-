import { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, HIT, radius } from '../src/theme/tokens';
import { MAX_SIZE, MIN_SIZE, clampSize } from '../src/engine/types';
import { createProject } from '../src/storage/projects';

const PRESETS = [
  { key: 'yt', label: 'YouTube thumbnail', w: 1280, h: 720 },
  { key: '1080', label: 'Full HD 1080p', w: 1920, h: 1080 },
  { key: '2k', label: '2K', w: 2560, h: 1440 },
  { key: 'sq', label: 'Square post', w: 1080, h: 1080 },
  { key: 'story', label: 'Story / Short', w: 1080, h: 1920 },
] as const;

export default function NewProject() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [preset, setPreset] = useState<string>('yt');
  const [customW, setCustomW] = useState('1280');
  const [customH, setCustomH] = useState('720');
  const [busy, setBusy] = useState(false);

  const size = () => {
    if (preset === 'custom') return { w: clampSize(Number(customW)), h: clampSize(Number(customH)) };
    const p = PRESETS.find((x) => x.key === preset)!;
    return { w: p.w, h: p.h };
  };

  const create = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { w, h } = size();
      const id = await createProject(name, w, h);
      router.replace({ pathname: '/editor/[id]', params: { id } });
    } catch (e) {
      setBusy(false);
      Alert.alert('Could not create project', e instanceof Error ? e.message : 'Unknown error.');
    }
  };

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 24 }}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={styles.title}>New project</Text>

      <Text style={styles.label}>Name</Text>
      <TextInput
        value={name}
        onChangeText={setName}
        placeholder="Untitled"
        placeholderTextColor={colors.textDim}
        style={styles.input}
      />

      <Text style={styles.label}>Canvas size</Text>
      {PRESETS.map((p) => (
        <Pressable
          key={p.key}
          onPress={() => setPreset(p.key)}
          style={[styles.option, preset === p.key && styles.optionOn]}
        >
          <Text style={styles.optionTitle}>{p.label}</Text>
          <Text style={styles.optionMeta}>{p.w} × {p.h}</Text>
        </Pressable>
      ))}
      <Pressable
        onPress={() => setPreset('custom')}
        style={[styles.option, preset === 'custom' && styles.optionOn]}
      >
        <Text style={styles.optionTitle}>Custom</Text>
        <Text style={styles.optionMeta}>{MIN_SIZE}–{MAX_SIZE} px</Text>
      </Pressable>
      {preset === 'custom' && (
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <TextInput value={customW} onChangeText={setCustomW} keyboardType="number-pad" style={[styles.input, { flex: 1 }]} />
          <TextInput value={customH} onChangeText={setCustomH} keyboardType="number-pad" style={[styles.input, { flex: 1 }]} />
        </View>
      )}

      <Pressable style={[styles.create, busy && { opacity: 0.6 }]} onPress={create}>
        <Text style={styles.createText}>Create project</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  title: { fontFamily: fonts.bold, fontSize: 28, color: colors.text, marginBottom: 20 },
  label: { fontFamily: fonts.medium, fontSize: 14, color: colors.textDim, marginTop: 16, marginBottom: 8 },
  input: {
    minHeight: HIT, paddingHorizontal: 14, borderRadius: radius.sm, backgroundColor: colors.panel,
    color: colors.text, fontFamily: fonts.medium, fontSize: 16,
  },
  option: {
    minHeight: HIT + 4, paddingHorizontal: 14, marginBottom: 8, borderRadius: radius.sm,
    backgroundColor: colors.panel, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', borderWidth: 1.5, borderColor: 'transparent',
  },
  optionOn: { borderColor: colors.accent, backgroundColor: colors.panelRaised },
  optionTitle: { fontFamily: fonts.bold, fontSize: 16, color: colors.text },
  optionMeta: { fontFamily: fonts.medium, fontSize: 14, color: colors.textDim },
  create: {
    marginTop: 24, minHeight: HIT + 8, borderRadius: radius.pill,
    backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center',
  },
  createText: { fontFamily: fonts.bold, fontSize: 17, color: colors.accentText },
});
