import { useEffect, useMemo, useState } from 'react';
import { LayoutChangeEvent, Pressable, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Canvas, Group, Path, Rect, Skia } from '@shopify/react-native-skia';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { useDerivedValue, useSharedValue, withTiming } from 'react-native-reanimated';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, HIT, radius } from '../../src/theme/tokens';
import { ArtLabDocument } from '../../src/engine/types';
import { loadDocument } from '../../src/storage/projects';
import { getSetting, setSetting } from '../../src/storage/db';

type Hand = 'left' | 'right';
const FIT_MARGIN = 24;

export default function Editor() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [doc, setDoc] = useState<ArtLabDocument | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<{ w: number; h: number } | null>(null);
  const [showGrid, setShowGrid] = useState(false);
  const [hand, setHand] = useState<Hand>('right');

  useEffect(() => {
    loadDocument(String(id)).then(setDoc).catch((e) => setError(e instanceof Error ? e.message : 'Could not open project.'));
    getSetting('hand').then((v) => v && setHand(v === 'left' ? 'left' : 'right'));
  }, [id]);

  // Canvas camera (screen = translate + scale * document point)
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const sc = useSharedValue(1);
  const fitTx = useSharedValue(0);
  const fitTy = useSharedValue(0);
  const fitSc = useSharedValue(1);
  const s0 = useSharedValue(1);
  const tx0 = useSharedValue(0);
  const ty0 = useSharedValue(0);
  const fx0 = useSharedValue(0);
  const fy0 = useSharedValue(0);

  useEffect(() => {
    if (!doc || !view) return;
    const s = Math.min((view.w - FIT_MARGIN * 2) / doc.width, (view.h - FIT_MARGIN * 2) / doc.height);
    fitSc.value = s;
    fitTx.value = (view.w - doc.width * s) / 2;
    fitTy.value = (view.h - doc.height * s) / 2;
    sc.value = s;
    tx.value = fitTx.value;
    ty.value = fitTy.value;
  }, [doc, view, fitSc, fitTx, fitTy, sc, tx, ty]);

  const fit = () => {
    sc.value = withTiming(fitSc.value);
    tx.value = withTiming(fitTx.value);
    ty.value = withTiming(fitTy.value);
  };

  const gesture = useMemo(() => {
    const pinch = Gesture.Pinch()
      .onStart((e) => {
        s0.value = sc.value;
        tx0.value = tx.value;
        ty0.value = ty.value;
        fx0.value = e.focalX;
        fy0.value = e.focalY;
      })
      .onUpdate((e) => {
        const ns = Math.min(32, Math.max(fitSc.value * 0.25, s0.value * e.scale));
        const k = ns / s0.value;
        tx.value = e.focalX - (fx0.value - tx0.value) * k;
        ty.value = e.focalY - (fy0.value - ty0.value) * k;
        sc.value = ns;
      });
    const pan = Gesture.Pan()
      .minPointers(1)
      .maxPointers(1)
      .onStart(() => {
        tx0.value = tx.value;
        ty0.value = ty.value;
      })
      .onUpdate((e) => {
        tx.value = tx0.value + e.translationX;
        ty.value = ty0.value + e.translationY;
      });
    const doubleTap = Gesture.Tap()
      .numberOfTaps(2)
      .onEnd((_e, ok) => {
        if (!ok) return;
        sc.value = withTiming(fitSc.value);
        tx.value = withTiming(fitTx.value);
        ty.value = withTiming(fitTy.value);
      });
    return Gesture.Simultaneous(pinch, pan, doubleTap);
  }, [s0, tx0, ty0, fx0, fy0, sc, tx, ty, fitSc, fitTx, fitTy]);

  const transform = useDerivedValue(() => [
    { translateX: tx.value },
    { translateY: ty.value },
    { scale: sc.value },
  ]);
  const hairline = useDerivedValue(() => 1 / sc.value);
  const frameStroke = useDerivedValue(() => 2 / sc.value);

  const checker = useMemo(() => {
    const p = Skia.PathBuilder.Make();
    if (!doc) return p.build();
    const c = Math.max(16, Math.ceil(Math.max(doc.width, doc.height) / 48));
    for (let y = 0; y * c < doc.height; y++) {
      for (let x = 0; x * c < doc.width; x++) {
        if ((x + y) % 2 === 1) {
          p.addRect(Skia.XYWHRect(x * c, y * c, Math.min(c, doc.width - x * c), Math.min(c, doc.height - y * c)));
        }
      }
    }
    return p.build();
  }, [doc]);

  const grid = useMemo(() => {
    const p = Skia.PathBuilder.Make();
    if (!doc) return p.build();
    let g = 64;
    while (Math.max(doc.width, doc.height) / g > 48) g *= 2;
    for (let x = g; x < doc.width; x += g) { p.moveTo(x, 0); p.lineTo(x, doc.height); }
    for (let y = g; y < doc.height; y += g) { p.moveTo(0, y); p.lineTo(doc.width, y); }
    return p.build();
  }, [doc]);

  const flipHand = () => {
    const next: Hand = hand === 'right' ? 'left' : 'right';
    setHand(next);
    setSetting('hand', next);
  };

  if (error) {
    return (
      <View style={[styles.center, { paddingTop: insets.top }]}>
        <Text style={styles.errTitle}>Can't open this project</Text>
        <Text style={styles.errBody}>{error}</Text>
        <Pressable style={styles.errBtn} onPress={() => router.back()}>
          <Text style={styles.errBtnText}>Back to projects</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <GestureDetector gesture={gesture}>
        <View
          style={StyleSheet.absoluteFill}
          onLayout={(e: LayoutChangeEvent) => setView({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
        >
          <Canvas style={StyleSheet.absoluteFill}>
            {doc && (
              <Group transform={transform}>
                <Rect x={0} y={0} width={doc.width} height={doc.height} color="#D9D9E2" />
                <Path path={checker} color="#B9B9C6" />
                {showGrid && <Path path={grid} style="stroke" strokeWidth={hairline} color="rgba(20,17,43,0.45)" />}
                <Rect x={0} y={0} width={doc.width} height={doc.height} style="stroke" strokeWidth={frameStroke} color={colors.frame} />
              </Group>
            )}
          </Canvas>
        </View>
      </GestureDetector>

      <View style={[styles.top, { top: insets.top + 8 }]} pointerEvents="box-none">
        <Pressable style={styles.iconBtn} onPress={() => router.back()} accessibilityLabel="Back to projects">
          <Feather name="chevron-left" size={24} color={colors.text} />
        </Pressable>
        <View style={styles.titlePill}>
          <Text style={styles.title} numberOfLines={1}>{doc?.name ?? ''}</Text>
          {doc && <Text style={styles.dims}>{doc.width} × {doc.height} px</Text>}
        </View>
      </View>

      <View
        style={[
          styles.toolbar,
          { bottom: insets.bottom + 16 },
          hand === 'right' ? { right: 16 } : { left: 16 },
        ]}
      >
        <Pressable style={styles.iconBtn} onPress={fit} accessibilityLabel="Fit canvas to screen">
          <Feather name="maximize" size={22} color={colors.text} />
        </Pressable>
        <Pressable
          style={[styles.iconBtn, showGrid && styles.iconBtnOn]}
          onPress={() => setShowGrid((g) => !g)}
          accessibilityLabel="Toggle grid"
        >
          <Feather name="grid" size={22} color={showGrid ? colors.accentText : colors.text} />
        </Pressable>
        <Pressable style={styles.iconBtn} onPress={flipHand} accessibilityLabel="Switch toolbar side">
          <Feather name={hand === 'right' ? 'align-left' : 'align-right'} size={22} color={colors.text} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink },
  center: { flex: 1, backgroundColor: colors.ink, alignItems: 'center', justifyContent: 'center', padding: 24 },
  errTitle: { fontFamily: fonts.bold, fontSize: 22, color: colors.text, marginBottom: 8 },
  errBody: { fontFamily: fonts.medium, fontSize: 15, color: colors.textDim, textAlign: 'center', marginBottom: 20 },
  errBtn: { minHeight: HIT, paddingHorizontal: 22, borderRadius: radius.pill, backgroundColor: colors.accent, justifyContent: 'center' },
  errBtnText: { fontFamily: fonts.bold, fontSize: 16, color: colors.accentText },
  top: { position: 'absolute', left: 12, right: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  titlePill: {
    flexShrink: 1, minHeight: HIT, paddingHorizontal: 16, justifyContent: 'center',
    borderRadius: radius.pill, backgroundColor: 'rgba(27,29,40,0.92)',
  },
  title: { fontFamily: fonts.bold, fontSize: 15, color: colors.text },
  dims: { fontFamily: fonts.medium, fontSize: 12, color: colors.textDim },
  toolbar: {
    position: 'absolute', flexDirection: 'row', gap: 6, padding: 6,
    borderRadius: radius.pill, backgroundColor: 'rgba(27,29,40,0.94)',
    borderWidth: 1, borderColor: colors.line,
  },
  iconBtn: {
    width: HIT, height: HIT, borderRadius: radius.pill, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(27,29,40,0.94)',
  },
  iconBtnOn: { backgroundColor: colors.accent },
});
