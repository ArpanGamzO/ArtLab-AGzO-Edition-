import { useCallback, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { colors, fonts, HIT, radius } from '../src/theme/tokens';
import { ProjectRow, listProjects } from '../src/storage/db';

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [projects, setProjects] = useState<ProjectRow[]>([]);

  useFocusEffect(
    useCallback(() => {
      listProjects().then(setProjects);
    }, []),
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 24 }]}>
      <Text style={styles.brand}>ART LAB</Text>
      <Text style={styles.edition}>AGzO Edition</Text>

      <FlatList
        data={projects}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ paddingBottom: insets.bottom + 120, paddingTop: 28 }}
        ListEmptyComponent={
          <Text style={styles.empty}>No projects yet. Start with a 1280 × 720 thumbnail.</Text>
        }
        renderItem={({ item }) => (
          <Pressable
            style={styles.row}
            onPress={() => router.push({ pathname: '/editor/[id]', params: { id: item.id } })}
          >
            <View style={styles.thumb}>
              <View
                style={{
                  aspectRatio: item.width / item.height,
                  width: item.width >= item.height ? 40 : undefined,
                  height: item.width < item.height ? 40 : undefined,
                  borderWidth: 1.5,
                  borderColor: colors.frame,
                }}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle} numberOfLines={1}>{item.name}</Text>
              <Text style={styles.rowMeta}>
                {item.width} × {item.height} px · edited {new Date(item.updatedAt).toLocaleDateString()}
              </Text>
            </View>
            <Feather name="chevron-right" size={20} color={colors.textDim} />
          </Pressable>
        )}
      />

      <Pressable
        style={[styles.fab, { bottom: insets.bottom + 20 }]}
        onPress={() => router.push('/new')}
        accessibilityLabel="New project"
      >
        <Feather name="plus" size={22} color={colors.accentText} />
        <Text style={styles.fabText}>New project</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.ink, paddingHorizontal: 20 },
  brand: { fontFamily: fonts.bold, fontSize: 44, letterSpacing: 2, color: colors.text },
  edition: { fontFamily: fonts.medium, fontSize: 15, color: colors.frame, marginTop: 2 },
  empty: { fontFamily: fonts.medium, color: colors.textDim, fontSize: 16, lineHeight: 24 },
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 72,
    paddingVertical: 10, paddingHorizontal: 14, marginBottom: 10,
    backgroundColor: colors.panel, borderRadius: radius.md,
  },
  thumb: {
    width: 52, height: 52, borderRadius: radius.sm, backgroundColor: colors.ink,
    alignItems: 'center', justifyContent: 'center',
  },
  rowTitle: { fontFamily: fonts.bold, fontSize: 17, color: colors.text },
  rowMeta: { fontFamily: fonts.medium, fontSize: 13, color: colors.textDim, marginTop: 2 },
  fab: {
    position: 'absolute', right: 20, minHeight: HIT + 8, paddingHorizontal: 22,
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: colors.accent, borderRadius: radius.pill,
  },
  fabText: { fontFamily: fonts.bold, fontSize: 16, color: colors.accentText },
});
