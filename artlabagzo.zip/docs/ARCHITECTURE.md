# Architecture

- `app/` Expo Router screens: `index` (projects), `new` (modal), `editor/[id]`.
- `src/theme/` design tokens.
- `src/engine/types.ts` document model: `ArtLabDocument` (version, size, layers bottom-to-top). Layer kinds: raster, text, shape, asset, adjustment, group. Files are referenced by path, never temporary URIs.
- `src/storage/db.ts` SQLite: `projects` (metadata) and `settings` (key/value).
- `src/storage/projects.ts` `.artlab` files in the app document directory, written to `.tmp` then swapped in.

## `.artlab` format v1
JSON of `ArtLabDocument`. Loader rejects files with a newer `version`. Binary layer data and masks will live beside the JSON and be referenced by relative file path.

## Camera
Screen position = translate + scale x document point, held in Reanimated shared values so gestures run on the UI thread.
