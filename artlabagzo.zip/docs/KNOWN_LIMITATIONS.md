# Known limitations (Phase 1)

- Not yet run on a physical device or emulator. Verified: strict typecheck passes, Android Hermes bundle builds.
- The editor shows the canvas only. No layers, tools, text, effects, assets, export or undo yet.
- Default Expo icon and splash image are still in use.
- No automated tests yet.
- iOS has not been built or tested.
- Skia needs a dev or release build; Expo Go may not work.
- APK is debug-key signed (sideload only). The CI workflow has not run yet, so the first cloud build may need small fixes.
